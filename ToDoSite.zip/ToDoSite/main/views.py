from django.shortcuts import render , redirect
from django.contrib import messages 

def index(request):   
    return render(request,"index.html")

def register(request):
    return render(request,'register.html')

def login(request):
    return render(request,'login.html')

from .forms import TodoForm 
from .models import Todo 
from django.contrib.auth.decorators import login_required

  
############################################### 
@login_required(login_url="/accounts/login")
def index(request): 
    user = request.user
    print(user.id)
    todo_list = Todo.objects.filter(user_id= user.id).order_by("-date") 
    if request.method == "POST": 
        form = TodoForm(request.POST) 
        if form.is_valid(): 
            ob = form.save(commit=False)
            ob.user = user
            print(ob.user.id)
            ob.save() 
            print(ob)
            return redirect('index') 
    form = TodoForm() 
    page = { 
            "forms" : form, 
            "todo_list" : todo_list, 
            }
    return render(request, 'index.html', page) 



def remove(request, item_id): 
    item = Todo.objects.get(id=item_id) 
    item.delete() 
    messages.info(request, "item removed !!!") 
    return redirect('index') 