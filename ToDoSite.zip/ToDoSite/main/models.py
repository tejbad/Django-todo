from django.db import models
from django.contrib.auth.models import User
# Create your models here.

from django.utils import timezone 
  
class Todo(models.Model): 
    user = models.ForeignKey(User,to_field='id',on_delete=models.CASCADE,related_name='todo')
    title=models.CharField(max_length=100) 
    details=models.TextField() 
    date=models.DateTimeField(default=timezone.now) 
  
    
